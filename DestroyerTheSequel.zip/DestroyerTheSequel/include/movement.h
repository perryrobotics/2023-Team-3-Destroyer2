void forward(int speed, int ticks);
void backward(int speed, int ticks);
void left(int speed, int ticks);
void right(int speed, int ticks);