#define LM 3
#define RM 0

#define BLACK 3500
#define FRONT_LINE 0
